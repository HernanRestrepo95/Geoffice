validarSesion();
$(document).ready(function () {
	
	$('#gestionProfesores').click(function () {
		gestionProfesores();
	});
	
    $("#gestionOficinas").click(function () {
		gestionarOficinas();
    });
});

function gestionProfesores(){
	$.ajax({
		type: "GET",
		url: "frm/gestionarProfesores.html",
		dataType: "html",
		success: function (data) {
			$('#main-page').html(data);
		}
	});
}

function gestionarOficinas(){
	$.ajax({
		type: "GET",
		url: "frm/gestionarOficinas.html",
		dataType: "html",
		success: function (data) {
			$('#main-page').html(data);
		}
	});
}